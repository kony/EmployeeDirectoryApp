function AS_Button_df5c1e7270404c36a3f0c5b5e57f3b79(eventobject) {
    var self = this;
    this.navigateFlex(this, "100%");
    this.reanimateTheWidgetsInDetailsPage();
    this.view.forceLayout();
}