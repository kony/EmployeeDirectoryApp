function AS_FlexContainer_d7ce472aa0b04378837e98cea2b1cce7(eventobject) {
    var self = this;
    this.onClickOfEmailFlex();
}