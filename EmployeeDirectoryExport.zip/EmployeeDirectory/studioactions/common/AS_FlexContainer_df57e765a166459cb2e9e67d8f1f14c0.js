function AS_FlexContainer_df57e765a166459cb2e9e67d8f1f14c0(eventobject) {
    var self = this;
    kony.store.setItem("inputType", "social");
    this.invokeIdentityService("EmpDirectryAD");
}