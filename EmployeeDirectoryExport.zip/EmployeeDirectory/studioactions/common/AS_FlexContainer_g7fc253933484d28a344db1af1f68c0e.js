function AS_FlexContainer_g7fc253933484d28a344db1af1f68c0e(eventobject) {
    var self = this;
    this.onClickOfCallFlex(this.view.lblCallMobileValue.text);
}