function AS_FlexContainer_e0c3f52569d347ed857e7070f5a6177f(eventobject) {
    var self = this;
    this.onClickOfCallFlex(this.view.lblCallWorkValue.text);
}