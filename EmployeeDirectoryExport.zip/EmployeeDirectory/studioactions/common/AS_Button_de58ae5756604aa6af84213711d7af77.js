function AS_Button_de58ae5756604aa6af84213711d7af77(eventobject) {
    var self = this;
    var nav = new kony.mvc.Navigation("frmKnwldgFrmwrk");
    nav.navigate();
}